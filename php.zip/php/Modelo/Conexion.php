<?php 

    $Conexion=new mysqli("localhost","root","","login");
    $Conexion->set_charset("utf8");

?>