<?php 
session_start();
if (empty($_SESSION["id"])) {
  header("location: index.php");
}


?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Página de Inicio</title>
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  <!-- Barra de Navegación -->
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#">Mi Sitio</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item active">
          <a class="nav-link" href="#">Inicio <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Características</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Precios</a>
        </li>
        <li class="nav-item">
          <a type="button" class="btn btn-outline-danger" href="controlador/controlador_cerrar_sesion.php" " >Cerrar sesion</a>
        </li>
      </ul>
    </div>
  </nav>

  <!-- Contenido Principal -->
  <div class="container mt-5">
    <div class="jumbotron">
      <h1 class="display-4">

      <?php
         echo "Hola ";
          echo $_SESSION["nombre"];
          echo " Bienvenido."
      ?>

      </h1>
      <p class="lead">Esta es una página de inicio simple con una barra de navegación superior.</p>
      <hr class="my-4">
      <p>Utiliza clases de utilidad para tipografía y espaciado para separar el contenido dentro del contenedor más grande.</p>
      <a class="btn btn-primary btn-lg" href="#" role="button">Aprende más</a>
    </div>
  </div>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
