<?php
session_start();

include "Modelo/Conexion.php";

if (!empty($_POST["btningresar"])) {
if (!empty($_POST["usuario"]) and !empty($_POST["password"])) {
$usuario=$_POST["usuario"];
$password=$_POST["password"];
    $sql=$Conexion->query("select * from usuario where usuario ='$usuario' and clave='$password' ");
if ($datos=$sql->fetch_object()) {
    $_SESSION["id"]=$datos->id; 
    $_SESSION["nombre"]=$datos->nombres; 
    $_SESSION["apellido"]=$datos->apellidos; 
header("Location: Home.php");
} else {
echo "<div class='alert alert-danger'>Acceso denegado</div>";
}
} else {
echo "Campos vacios";
}
}
?>